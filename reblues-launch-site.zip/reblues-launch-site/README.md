# Reblues Launch — reblueslaunch.com

The marketing site for Reblues Launch, a launch-film and distribution studio by Reblues Media.

## What's here
- `index.html` is the whole site in one self-contained file (HTML, CSS and JS inline). It includes hash routes `#/work`, `#/case/<slug>` and `#/journal`.
- `ASSETS.md` lists every image and film. They're hosted in the public Supabase bucket `launch-films` (project `ocoqzvxhrwnqsrifcraw`).

## External dependencies
- Fonts: Inter Tight and IBM Plex Mono (Google Fonts)
- GSAP 3.12.5 + ScrollTrigger, and Lenis 1.1.13 (unpkg)

## Run locally
Open `index.html` in a browser, or serve it: `npx serve .`

## Deploy
It's a static site, so it drops into Vercel, Netlify or Cloudflare Pages with no build step.

## Open items
- Hero H1 uses a `--hero-font` placeholder until the final font is supplied.
- `LAUNCH_DATE` is a placeholder (2026-11-16).
- Final case-study copy and PDFs are pending.
- The 10x case title mentions a view count. Review it against the no-view-counts rule.
- Add SRI hashes for the GSAP and Lenis scripts, or self-host them.
- A `Content-Security-Policy` meta tag is in `<head>`. Widen it if you add analytics or new hosts.
